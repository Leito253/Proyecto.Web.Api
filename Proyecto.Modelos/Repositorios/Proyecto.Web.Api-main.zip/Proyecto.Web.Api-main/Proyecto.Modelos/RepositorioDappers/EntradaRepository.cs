using System.Data;
using Dapper;
using MySql.Data.MySqlClient;
using Proyecto.Modelos.Entidades;

namespace Proyecto.Web.Api.Repositorios
{
    public class EntradaRepository : IEntradaRepository
    {
        

    }
}