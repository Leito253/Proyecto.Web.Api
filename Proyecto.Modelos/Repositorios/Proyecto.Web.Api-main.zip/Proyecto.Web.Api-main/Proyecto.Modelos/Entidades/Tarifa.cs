namespace Proyecto.Modelos.Entidades;
public class Tarifa
{
    public decimal Precio { get; set; }
    
}